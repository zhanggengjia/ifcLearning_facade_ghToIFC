# ifc_assembly.py
# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple

# ----------------------------
# Optional GH imports
# ----------------------------
try:
    import Grasshopper  # type: ignore
    from Grasshopper import DataTree  # type: ignore
    from Grasshopper.Kernel.Data import GH_Path  # type: ignore
    from Grasshopper.Kernel.Types import GH_ObjectWrapper  # type: ignore
except Exception:  # pragma: no cover
    Grasshopper = None
    DataTree = None
    GH_Path = None
    GH_ObjectWrapper = None


# ----------------------------
# Minimal Payload helpers
# ----------------------------
Payload = Dict[str, Any]


def ensure_dict(x: Any) -> Dict[str, Any]:
    return dict(x) if isinstance(x, Mapping) else {}


def _unwrap_gh_wrapper(x: Any) -> Any:
    """
    GH_ObjectWrapper safe unwrap:
    - Rhino/Grasshopper wrapper commonly exposes .Value
    """
    try:
        if hasattr(x, "Value"):
            return x.Value
    except Exception:
        pass
    return x


def unwrap_payload(x: Any) -> Optional[Payload]:
    """
    Accept dict payloads AND GH_ObjectWrapper(payload).
    """
    x2 = _unwrap_gh_wrapper(x)
    return x2 if isinstance(x2, dict) else None


def _safe_copy_any(x: Any, *, _depth: int = 0, _max_depth: int = 50) -> Any:
    """
    Brep-safe recursive copy:
    - dict/list/tuple: recursively copy
    - other objects: try deepcopy; if fails, keep reference
    """
    if _depth > _max_depth:
        return x

    x = _unwrap_gh_wrapper(x)

    if isinstance(x, dict):
        out: Dict[Any, Any] = {}
        for k, v in x.items():
            out[_safe_copy_any(k, _depth=_depth + 1, _max_depth=_max_depth)] = _safe_copy_any(
                v, _depth=_depth + 1, _max_depth=_max_depth
            )
        return out

    if isinstance(x, list):
        return [_safe_copy_any(v, _depth=_depth + 1, _max_depth=_max_depth) for v in x]

    if isinstance(x, tuple):
        return tuple(_safe_copy_any(v, _depth=_depth + 1, _max_depth=_max_depth) for v in x)

    if x is None or isinstance(x, (int, float, bool, str)):
        return x

    try:
        import copy

        return copy.deepcopy(x)
    except Exception:
        return x


def deep_copy_payload(p: Payload) -> Payload:
    """
    Payload copy that NEVER deepcopy 'geo' (Rhino Brep is not picklable),
    but still deep-copies dict/list structures like props/pset_overrides.
    """
    p = _unwrap_gh_wrapper(p)
    if not isinstance(p, dict):
        return p

    out: Payload = {}
    for k, v in p.items():
        if k == "geo":
            out[k] = v  # keep reference (Brep-safe)
        else:
            out[k] = _safe_copy_any(v)
    return out


def normalize_payload_inplace(p: Payload, *, default_schema: int = 1, default_category: str = "") -> Payload:
    if not isinstance(p, dict):
        return p
    p.setdefault("schema", default_schema)
    p.setdefault("category", default_category)
    if p.get("props") is None:
        p["props"] = {}
    p.setdefault("props", {})
    return p


def is_datatree_like(x: Any) -> bool:
    return hasattr(x, "Paths") and hasattr(x, "Branch")


def new_datatree() -> Any:
    if DataTree is None:
        raise RuntimeError("Grasshopper DataTree not available")
    return DataTree[object]()


def to_branch_dict_any(x: Any) -> Dict[str, List[Any]]:
    """
    Convert GH DataTree or dict-like to { "{0}": [items], ... }
    Note: keep original items (may be wrapped) — unwrap happens later.
    """
    out: Dict[str, List[Any]] = {}
    if is_datatree_like(x):
        for ghp in list(x.Paths):
            out[str(ghp)] = list(x.Branch(ghp))
        return out
    if isinstance(x, dict):
        return {str(k): list(v) for k, v in x.items()}
    if isinstance(x, list):
        return {"{0}": list(x)}
    return {"{0}": [x]}


def pathstr_to_ghpath(p: str) -> Any:
    """
    Parse "{0;1}" into GH_Path(0,1). Fallback returns p if GH_Path not available.
    """
    if GH_Path is None:
        return p
    s = str(p).strip().lstrip("{").rstrip("}")
    if not s:
        return GH_Path(0)
    parts = [int(x) for x in s.replace(",", ";").split(";") if x.strip() != ""]
    return GH_Path(*parts)


def iter_payloads_from_any(x: Any) -> Iterable[Payload]:
    if is_datatree_like(x):
        for ghp in list(x.Paths):
            for it in list(x.Branch(ghp)):
                p = unwrap_payload(it)
                if p:
                    yield p
        return

    if isinstance(x, list):
        for br in x:
            if isinstance(br, list):
                for it in br:
                    p = unwrap_payload(it)
                    if p:
                        yield p
        return

    if isinstance(x, dict):
        for _, br in x.items():
            for it in br:
                p = unwrap_payload(it)
                if p:
                    yield p


def _wrap_for_gh(x: Any) -> Any:
    """
    Always wrap dict payload into GH_ObjectWrapper for stable GH behavior.
    """
    if GH_ObjectWrapper is None:
        return x
    if isinstance(x, dict):
        return GH_ObjectWrapper(x)
    return x


# ----------------------------
# Core logic
# ----------------------------
def _stable_outer_wrap_assembly_path(props: Dict[str, Any], *, name: str, key: str, role: str) -> None:
    ap = props.get("assembly_path")
    if not isinstance(ap, list):
        ap = []
    entry = {"name": name, "key": key, "role": role}
    props["assembly_path"] = [entry] + list(ap)


def _make_assembly_meta_payload(
    *,
    unit_id: str,
    pset_overrides: Dict[str, Any],
    schema: int = 1,
    assembly_path_depth: int = 0,
) -> Payload:
    return {
        "schema": int(schema),
        "unit_id": unit_id,
        "geo": None,
        "name": "__ASSEMBLY_META__",
        "category": "__ASSEMBLY_META__",
        "props": {
            "kind": "AssemblyMeta",
            "scope": "ASSEMBLY",
            "unit_id": unit_id,
            "assembly_path_depth": int(assembly_path_depth),
            "pset_overrides": pset_overrides,
        },
    }


def _coerce_kv_to_dict(keys: Any, values: Any) -> Dict[str, Any]:
    def _flatten_any(x: Any) -> List[Any]:
        if is_datatree_like(x):
            out: List[Any] = []
            for ghp in list(x.Paths):
                out.extend(list(x.Branch(ghp)))
            return out
        if isinstance(x, list):
            return list(x)
        if x is None:
            return []
        return [x]

    k_list = _flatten_any(keys)
    v_list = _flatten_any(values)

    out: Dict[str, Any] = {}
    n = min(len(k_list), len(v_list))
    for i in range(n):
        k = k_list[i]
        if k is None:
            continue
        ks = str(k).strip()
        if not ks:
            continue
        out[ks] = v_list[i]
    return out


def _coerce_unitid_hint(UnitId: Any) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if UnitId is None:
        return out

    if isinstance(UnitId, str):
        out["*"] = UnitId.strip()
        return out

    if is_datatree_like(UnitId):
        try:
            for ghp in list(UnitId.Paths):
                items = list(UnitId.Branch(ghp))
                if not items:
                    continue
                s = str(items[0]).strip()
                if s:
                    out[str(ghp)] = s
        except Exception:
            return out
        return out

    if isinstance(UnitId, list):
        for i, v in enumerate(UnitId):
            if v is None:
                continue
            s = str(v).strip()
            if s:
                out[f"@idx:{i}"] = s
        return out

    s = str(UnitId).strip()
    if s:
        out["*"] = s
    return out


def annotate_subassembly(
    MatData: Any,
    Name: Any,
    KeySuffix: Any,
    Role: Any,
    Key: Any,
    Value: Any,
    UnitId: Any,
    Debug: bool = True,
) -> Tuple[Any, str]:
    """
    GH-API compatible signature:
        MatDataOut, Log = annotate_subassembly(MatData, Name, KeySuffix, Role, Key, Value, UnitId)
    """
    logs: List[str] = []

    asm_name = str(Name or "")
    role = str(Role or "")

    suffix = str(KeySuffix or "")
    asm_key = asm_name + suffix if suffix else asm_name

    kv = _coerce_kv_to_dict(Key, Value)
    pset_overrides_for_meta: Dict[str, Any] = {"Pset_Assembly": kv} if kv else {}

    md_bd = to_branch_dict_any(MatData)
    md_paths = list(md_bd.keys())

    want_tree = is_datatree_like(MatData)
    out_tree = new_datatree() if want_tree else None

    # Use original GH_Path objects when possible (prevents path mismatch)
    gh_path_map: Dict[str, Any] = {}
    if want_tree and hasattr(MatData, "Paths"):
        try:
            for ghp in list(MatData.Paths):
                gh_path_map[str(ghp)] = ghp
        except Exception:
            gh_path_map = {}

    unitid_hint = _coerce_unitid_hint(UnitId)

    if Debug:
        logs.append(
            "assembly: applied. Rule: stable outer wrap (prepend) on props['assembly_path']."
            " Unit branches preserved (Strategy S1)."
            " Assembly override: emits AssemblyMeta payloads (category='__ASSEMBLY_META__') with props['pset_overrides']."
        )

    per_branch_meta_counts: Dict[str, int] = {}
    out_list: List[List[Any]] = []

    for idx, p in enumerate(md_paths):
        branch_items = list(md_bd.get(p, []))
        new_branch_items: List[Any] = []

        touched = 0
        unit_id_for_branch: Optional[str] = None

        if p in unitid_hint:
            unit_id_for_branch = unitid_hint[p]
        elif "*" in unitid_hint:
            unit_id_for_branch = unitid_hint["*"]
        elif f"@idx:{idx}" in unitid_hint:
            unit_id_for_branch = unitid_hint[f"@idx:{idx}"]

        for it in branch_items:
            raw = unwrap_payload(it)
            if raw is None:
                new_branch_items.append(it)
                continue

            payload = deep_copy_payload(raw)  # Brep-safe
            normalize_payload_inplace(payload, default_schema=1, default_category=str(payload.get("category", "") or ""))

            props = ensure_dict(payload.get("props"))
            payload["props"] = props

            if unit_id_for_branch is None:
                uid = payload.get("unit_id") or props.get("unit_id")
                if isinstance(uid, str) and uid.strip():
                    unit_id_for_branch = uid.strip()

            _stable_outer_wrap_assembly_path(props, name=asm_name, key=asm_key, role=role)
            touched += 1
            new_branch_items.append(payload)

        added_meta = False
        if pset_overrides_for_meta and unit_id_for_branch:
            ap_depth = 0
            for it2 in new_branch_items:
                p2 = unwrap_payload(it2)
                if p2 and isinstance(p2.get("props"), dict):
                    ap = p2["props"].get("assembly_path")
                    if isinstance(ap, list):
                        ap_depth = len(ap)
                        break

            meta_payload = _make_assembly_meta_payload(
                unit_id=unit_id_for_branch,
                pset_overrides=pset_overrides_for_meta,
                schema=1,
                assembly_path_depth=ap_depth,
            )
            new_branch_items.append(meta_payload)
            added_meta = True

            if Debug:
                logs.append(
                    f"  [DEBUG] Created AssemblyMeta: path={p} unit_id={unit_id_for_branch!r} "
                    f"pset_overrides={pset_overrides_for_meta} assembly_path_depth={ap_depth}"
                )

        # ---------- write to out_tree ----------
        if out_tree is not None:
            ghp = gh_path_map.get(p)
            if ghp is None:
                ghp = pathstr_to_ghpath(p)

            for it3 in new_branch_items:
                out_tree.Add(_wrap_for_gh(it3), ghp)

            # Hard verification using out_tree directly (most reliable)
            if Debug:
                try:
                    br = list(out_tree.Branch(ghp))
                    br_len = len(br)
                    br_meta = 0
                    for bi in br:
                        px = unwrap_payload(bi)
                        if px and px.get("category") == "__ASSEMBLY_META__":
                            br_meta += 1
                    logs.append(f"  [DEBUG] OutTree branch check {p}: len={br_len} meta={br_meta}")
                except Exception:
                    pass

        out_list.append(new_branch_items)

        # Count meta robustly (unwrap wrapper)
        meta_in_branch = 0
        for itx in new_branch_items:
            px = unwrap_payload(itx)
            if px and px.get("category") == "__ASSEMBLY_META__":
                meta_in_branch += 1
        per_branch_meta_counts[p] = meta_in_branch

        if Debug:
            logs.append(f"{p}: annotated={touched} added_meta={'Y' if added_meta else 'N'} meta_in_branch={meta_in_branch}")

    if Debug:
        all_payloads = list(iter_payloads_from_any(out_tree if out_tree is not None else out_list))
        cats: Dict[str, int] = {}
        for pp in all_payloads:
            cats[str(pp.get("category", ""))] = cats.get(str(pp.get("category", "")), 0) + 1
        logs.append(f"[DEBUG] Output verification: total={len(all_payloads)} categories={cats}")
        logs.append(f"[DEBUG] Per-branch meta counts: {per_branch_meta_counts}")

    MatDataOut = out_tree if out_tree is not None else out_list
    LogStr = "\n".join(logs)
    return MatDataOut, LogStr
